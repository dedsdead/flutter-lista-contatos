class Routes {
  static const home = '/';
  static const form = '/form';
  static const search = '/search';
}
