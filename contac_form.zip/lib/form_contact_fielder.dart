import 'package:flutter/material.dart';

class FormContactFielder extends StatelessWidget {
  final String hintText;
  final IconData iconData;
  final TextEditingController controller;
  final TextInputType textInputType;

  const FormContactFielder(
      {super.key,
      required this.hintText,
      required this.iconData,
      required this.controller,
      this.textInputType = TextInputType.text});

  @override
  Widget build(BuildContext context) {
    return TextFormField(
      controller: controller,
      keyboardType: textInputType,
      decoration: InputDecoration(
          hintText: hintText, filled: true, icon: Icon(iconData)),
    );
  }
}
