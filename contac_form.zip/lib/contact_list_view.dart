import 'package:flutter/material.dart';
import 'package:formulario_contatos/model/user.dart';

class ContactListView extends StatelessWidget {
  const ContactListView({super.key, required this.users});

  final List<UserModel> users;

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      shrinkWrap: true,
      itemCount: users.length,
      itemBuilder: (context, index) {
        return Card(
          child: ExpansionTile(
            title: Text(
                "${users.elementAt(index).userId} [${users.elementAt(index).userEmail}]",
                style:
                    const TextStyle(fontWeight: FontWeight.bold, fontSize: 18)),
            subtitle: Text(users.elementAt(index).userName),
            children: <Widget>[
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceAround,
                children: <Widget>[
                  TextButton.icon(
                      onPressed: () {},
                      icon: Icon(
                        Icons.edit,
                        color: Colors.amber.shade600,
                      ),
                      label: Text("Editar",
                          style: TextStyle(color: Colors.amber.shade600))),
                  TextButton.icon(
                      onPressed: () {},
                      icon: const Icon(
                        Icons.edit,
                        color: Colors.pink,
                      ),
                      label: const Text("Excluir",
                          style: TextStyle(color: Colors.pink))),
                ],
              )
            ],
          ),
        );
      },
    );
  }
}
