import 'package:flutter/material.dart';
import 'package:formulario_contatos/common/box_user.dart';
import 'package:formulario_contatos/contact_list_view.dart';
import 'package:formulario_contatos/model/user.dart';
import 'package:hive/hive.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'form_contact_fielder.dart';

class HomeContact extends StatefulWidget {
  const HomeContact({super.key});

  @override
  State<HomeContact> createState() => _HomeContactState();
}

class _HomeContactState extends State<HomeContact> {
  final _formKey = GlobalKey<FormState>();

  final idUserControl = TextEditingController();
  final nameUserControl = TextEditingController();
  final emailUserControl = TextEditingController();

  void _clearTextControllers() {
    idUserControl.clear();
    nameUserControl.clear();
    emailUserControl.clear();
  }

  @override
  void dispose() {
    idUserControl.dispose();
    nameUserControl.dispose();
    emailUserControl.dispose();
    Hive.close();
    super.dispose();
  }

  List<UserModel> generateData() {
    List<UserModel> users = [];
    UserModel user = UserModel()
      ..userId = "aaa"
      ..userName = "aaa"
      ..userEmail = "aaa@aaa.aaa";

    users.add(user);
    users.add(user);
    users.add(user);
    users.add(user);

    return users;
  }

  @override
  Widget build(BuildContext context) {
    List<UserModel> users = generateData();
    return Form(
      key: _formKey,
      child: Scaffold(
          appBar: AppBar(title: const Text("Lista de Contatos")),
          body: SingleChildScrollView(
            padding: const EdgeInsets.all(20),
            child: Column(children: <Widget>[
              FormContactFielder(
                hintText: "Codigo",
                iconData: Icons.person,
                controller: idUserControl,
              ),
              FormContactFielder(
                hintText: "Nome",
                iconData: Icons.person_outline,
                controller: nameUserControl,
              ),
              FormContactFielder(
                hintText: "Email",
                iconData: Icons.email_outlined,
                controller: emailUserControl,
                textInputType: TextInputType.emailAddress,
              ),
              Container(
                padding: const EdgeInsets.only(left: 40),
                child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                    children: <Widget>[
                      Expanded(
                          child: ElevatedButton(
                              onPressed: () {},
                              child: const Text("Adicionar"))),
                      const SizedBox(width: 20),
                      Expanded(
                          child: ElevatedButton(
                              onPressed: () {
                                _clearTextControllers();
                              },
                              child: const Text("Limpar Campos")))
                    ]),
              ),
              ValueListenableBuilder(
                  valueListenable: UserBox.getUsers().listenable(),
                  builder: (BuildContext context, Box userBox, Widget? child) {
                    final users = userBox.values.toList().cast<UserModel>();
                    if (users.isEmpty) {
                      return Center(child: const Text('No Users Found', style: ,),);
                    } else {
                      return 
                    }
                  },
                  child: ContactListView(users: users))
            ]),
          )),
    );
  }
}
